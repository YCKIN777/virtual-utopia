# 虚拟乌托邦项目｜阶段五完整记忆文档
> 用途：归档Phase5 SQLite持久化服务的模块结构、数据表、API、模式开关、测试结果、启动顺序和冻结状态。
> 适用：总控Agent / CodeX读取，掌握阶段五完整上下文，保护阶段一至阶段四冻结成果不被改动。

## 1. 项目全局状态
项目名称：virtual-utopia BP2

当前整体状态：
- 阶段一【已冻结】：工程、HIG组件、矢量地图和六场景容器已交付。
- 阶段二【已冻结】：分支Agent、场景绑定、内存会话隔离和真实DeepSeek E2E已验收。
- 阶段三【已冻结】：独立RAG知识库服务已开发并完成自测。
- 阶段四【已冻结】：RAG与主Agent集成模块已开发并完成自测。
- 阶段五【开发+自测完成，冻结，等待整体项目验收】：独立SQLite持久化元数据服务已完成。

Phase5核心目标：在不修改阶段一至阶段四任何源码的前提下，新增独立SQLite持久化服务，提供用户认证、会话持久化、知识库文档元数据管理和RAG日志存储。

## 2. 模块位置与交付范围
模块目录：

```text
backend/src/phase5/
```

新增文件：

- `backend/src/phase5/config.js`
- `backend/src/phase5/database.js`
- `backend/src/phase5/errors.js`
- `backend/src/phase5/security.js`
- `backend/src/phase5/repositories.js`
- `backend/src/phase5/httpServer.js`
- `backend/src/phase5/sessionStoreAdapter.js`
- `backend/src/phase5/server.js`
- `backend/src/phase5/integratedServer.js`
- `backend/src/phase5/index.js`
- `backend/src/phase5/schema.sql`
- `backend/src/phase5/tests/phase5.persistence.e2e.mjs`

未修改：

- 阶段一至阶段四业务源码。
- `stage2_memory.md`
- `stage3_memory.md`
- `stage4_memory.md`
- `phase5_design.md`
- 项目原有`.env`文件。
- `backend/package.json`或`package-lock.json`。

## 3. 数据库技术选型
数据库：SQLite单文件本地数据库。

驱动：Node.js内置`node:sqlite`。

运行要求：

- 建议Node.js`>=22.5`。
- 当前验证环境Node.js`v24.18.0`。
- 不依赖PostgreSQL，不依赖外部数据库服务。

默认数据库文件：

```text
H:\BP2\data\virtual_utopia_phase5.sqlite
```

初始化配置：

- `PRAGMA journal_mode = WAL`
- `PRAGMA foreign_keys = ON`
- `PRAGMA busy_timeout`

四张核心数据表：

1. `users`
2. `chat_sessions`
3. `knowledge_documents`
4. `rag_logs`

## 4. 核心能力

### 4.1 用户账号与角色鉴权
当前实际实现角色：

| 角色 | 权限 |
| --- | --- |
| `admin` | 用户管理、全部会话、全部文档、全部日志 |
| `editor` | 文档元数据CRUD、自己的会话读写、自己的日志 |
| `viewer` | 只读文档元数据和自己的会话历史 |

补充说明：任务摘要中曾提及`admin/guest`，但当前已验收代码实现的是`admin/editor/viewer`，不存在`guest`角色。

认证能力：

- 用户名密码登录。
- 密码使用`scrypt`哈希保存。
- HMAC签名Bearer Token。
- 支持管理员初始化用户。
- 支持服务间`X-Phase5-Service-Token`调用。

### 4.2 会话持久化
- 保存公共会话和私聊会话。
- 保存`id`、用户、场景、会话类型和归属Agent。
- 保存消息历史、创建时间、更新时间和过期时间。
- 支持创建、读取、更新和软删除。
- 服务重启后会话和消息不丢失。
- 适配器兼容原`sessionStore`的`type`、`messages`、`expiresAt`等字段。

### 4.3 知识库文档元数据
- 新增文档元数据。
- 查询文档列表和详情。
- 更新标题、来源路径、哈希、分块数、集合名称和状态。
- 软删除文档元数据。
- 仅保存元数据，不保存Chroma向量内容。

### 4.4 RAG日志
- 保存RAG查询和入库操作日志。
- 保存用户、会话、集合、TopK、阈值、命中数和耗时。
- 支持按用户、会话、状态和时间查询。
- 支持单条日志读取。

## 5. SESSION_STORAGE_MODE模式开关

环境变量：

```text
SESSION_STORAGE_MODE=memory
```

可选模式：

| 模式 | 行为 |
| --- | --- |
| `memory` | 使用原内存会话实现，完全不调用Phase5 |
| `sqlite` | 使用Phase5 HTTP服务持久化会话 |

默认值：

```text
memory
```

`memory`模式保证阶段二至阶段四原始行为不变。

`sqlite`模式通过Phase5适配器持久化，不修改原`sessionStore`接口。

## 6. HTTP API清单

Phase5独立服务默认地址：

```text
http://localhost:3300
```

### 6.1 健康检查

| 方法 | 路径 |
| --- | --- |
| GET | `/health` |
| GET | `/api/phase5/health` |

### 6.2 登录与身份

| 方法 | 路径 |
| --- | --- |
| POST | `/api/phase5/auth/login` |
| GET | `/api/phase5/auth/me` |
| POST | `/api/phase5/auth/logout` |

### 6.3 用户管理

| 方法 | 路径 |
| --- | --- |
| POST | `/api/phase5/users` |
| GET | `/api/phase5/users` |
| PUT | `/api/phase5/users/:id` |

### 6.4 会话CRUD

| 方法 | 路径 |
| --- | --- |
| POST | `/api/phase5/sessions` |
| GET | `/api/phase5/sessions` |
| GET | `/api/phase5/sessions/:id` |
| PUT | `/api/phase5/sessions/:id` |
| DELETE | `/api/phase5/sessions/:id` |

### 6.5 文档元数据CRUD

| 方法 | 路径 |
| --- | --- |
| POST | `/api/phase5/documents` |
| GET | `/api/phase5/documents` |
| GET | `/api/phase5/documents/:id` |
| PUT | `/api/phase5/documents/:id` |
| DELETE | `/api/phase5/documents/:id` |

### 6.6 RAG日志

| 方法 | 路径 |
| --- | --- |
| POST | `/api/phase5/logs` |
| GET | `/api/phase5/logs` |
| GET | `/api/phase5/logs/:id` |

## 7. 环境变量

| 变量 | 默认值 | 说明 |
| --- | --- | --- |
| `PHASE5_ENABLED` | `false` | Phase5能力开关 |
| `PHASE5_PORT` | `3300` | Phase5 HTTP端口 |
| `PHASE5_DB_PATH` | `H:\BP2\data\virtual_utopia_phase5.sqlite` | SQLite文件 |
| `PHASE5_DB_BUSY_TIMEOUT_MS` | `5000` | SQLite忙等待 |
| `PHASE5_AUTH_SECRET` | 必填 | Token签名密钥 |
| `PHASE5_SERVICE_TOKEN` | 必填 | 服务间调用令牌 |
| `PHASE5_BOOTSTRAP_ADMIN_USERNAME` | `admin` | 初始化管理员 |
| `PHASE5_BOOTSTRAP_ADMIN_PASSWORD` | 必填 | 初始化管理员密码 |
| `PHASE5_TOKEN_TTL_SECONDS` | `28800` | Token有效期 |
| `PHASE5_LOG_RETENTION_DAYS` | `90` | 日志保留周期 |
| `SESSION_STORAGE_MODE` | `memory` | `memory`或`sqlite` |
| `PHASE5_BASE_URL` | `http://localhost:3300` | Phase5服务地址 |
| `PHASE5_TIMEOUT_MS` | `3000` | 客户端超时 |

## 8. 测试结果

独立E2E脚本：

```text
backend/src/phase5/tests/phase5.persistence.e2e.mjs
```

验证结果：

```json
{
  "sessionPersistenceAfterRestart": {
    "messages": 2
  },
  "documentPersistenceAfterRestart": {
    "chunkCount": 7,
    "status": "indexed"
  },
  "logPersistenceAfterRestart": {
    "count": 1
  },
  "memoryMode": {
    "phase5Calls": 0
  },
  "sqliteMode": {
    "restoredMessages": 2
  }
}
```

验证内容：

- 用户和管理员登录。
- 创建`editor`用户。
- 会话创建和消息写入。
- 文档元数据新增和更新。
- RAG日志写入和查询。
- Phase5服务关闭并重新启动。
- 重启后会话消息、文档元数据和日志均保持。
- `memory`模式调用Phase5次数为`0`。
- `sqlite`模式适配器重启后成功恢复会话。

全量回归：

- 新增JavaScript文件语法检查通过。
- 新增文件UTF-8、无BOM、LF换行。
- `npm run check`通过。
- 前端测试：9/9通过。
- 原阶段二后端测试：33/33通过。
- 原阶段一至阶段四测试全部保留，无回归失败。
- Phase5独立服务入口已验证可启动。
- 无额外npm依赖变更。

## 9. 架构边界
1. Phase5只负责元数据持久化，不接管Chroma向量存储。
2. `knowledge_documents`只保存文档元数据，向量仍保存在ChromaDB。
3. 不修改DeepSeek、RAG和Agent业务逻辑。
4. 不修改阶段二原有内存会话实现。
5. `sqlite`模式通过Phase5 HTTP服务访问SQLite，phase4不直接读取数据库文件。
6. `memory`模式保持原行为，完全不调用Phase5。
7. Phase5服务不可用时，`sqlite`模式请求失败，不回退内存，避免静默丢数据。

## 10. 启停与运行顺序

完整启动顺序：

`Chroma 8000 → Phase3 RAG服务 3100 → Phase5持久服务 3300 → Phase4主服务 3200 → 前端 5173`

Phase5服务：

```powershell
$env:PHASE5_PORT='3300'
$env:PHASE5_DB_PATH='H:\BP2\data\virtual_utopia_phase5.sqlite'
$env:PHASE5_AUTH_SECRET='replace-with-local-secret'
$env:PHASE5_SERVICE_TOKEN='replace-with-service-token'
$env:PHASE5_BOOTSTRAP_ADMIN_PASSWORD='replace-with-admin-password'
node backend/src/phase5/server.js
```

Phase5集成模式启动：

```powershell
$env:SESSION_STORAGE_MODE='sqlite'
$env:PHASE5_BASE_URL='http://localhost:3300'
$env:PHASE5_SERVICE_TOKEN='replace-with-service-token'
$env:PHASE4_PORT='3200'
node backend/src/phase5/integratedServer.js
```

内存模式启动：

```powershell
$env:SESSION_STORAGE_MODE='memory'
$env:PHASE4_PORT='3200'
node backend/src/phase5/integratedServer.js
```

## 11. 阶段五状态
阶段五状态：【开发+自测完成，冻结，等待整体项目验收】。

未收到新的明确指令前，不启动后续阶段开发，不扩展Phase5范围之外的业务功能。

## 12. 后续阶段更新记录

### 12.1 Phase5持久化 ↔ 3D前端集成

阶段名称：3D前端Phase5持久化接入

状态：开发完成，自测通过。

变更内容：

- 通过3400 Phase6网关读写Phase5持久化服务。
- 世界快照使用保留会话`world-<userId>`，不修改Phase5原有表结构。
- 世界快照仅保存用户地块ID、院落物品、室内家具和用户权限。
- 登录令牌使用浏览器`sessionStorage`保存，刷新后可恢复。
- Phase5不可用时保留内存模式回退。

### 12.2 家园装扮编辑器

阶段名称：拖拽式家园装扮编辑器

状态：开发完成，自测通过。

变更内容：

- 新增独立覆盖层组件`HomeDecorator.vue`，不修改Three.js场景美术结构。
- 支持院落与室内双模式。
- 支持家具素材拖拽放置、移动、旋转、删除和保存。
- editor/admin可管理自己的家园，viewer仅能漫游。
- 家园数据写入world快照，刷新页面后自动恢复。

### 12.3 多人在线Avatar

阶段名称：多人在线Avatar实时漫游

状态：开发完成，自测通过。

变更内容：

- 新增Phase6内存在线状态管理`presenceStore.js`。
- 前端每250ms同步位置、朝向和动画状态。
- 多个登录用户可互相看到Avatar。
- 新增在线用户列表，显示名称和角色。
- 离线或超时用户自动从在线列表移除。

### 12.4 Avatar行走与待机动画

阶段名称：Avatar动画增强

状态：开发完成，自测通过。

变更内容：

- Avatar增加独立四肢程序化动画。
- 静止时播放idle待机动作。
- WASD移动时自动切换walk步态，停止后恢复idle。
- 动画状态随presence同步，其他客户端可见。
- 不引入外部骨骼或动画资源。

### 12.5 世界多人文字聊天

阶段名称：虚拟世界多人文字聊天模块

状态：开发完成，自测通过。

变更内容：

- 新增全局世界频道，所有登录用户均可查看和发送消息。
- 消息附带发送账号名称、显示名称和发送时间。
- Phase6网关提供世界频道历史读取与消息发送接口。
- 聊天记录持久化到保留会话`world-chat-global`，不修改Phase5表结构。
- 后端使用顺序队列避免并发消息覆盖，最多保留最近200条。
- 前端使用短轮询获取新消息，新登录用户自动加载最近历史。
- 聊天面板位于右下角，支持打开、关闭、输入和发送。

### 12.6 当前完整能力清单

1. Three.js 3D山谷世界漫游。
2. 昼夜切换、雾气、风动和样板室内模式。
3. 50户木屋、生活广场、溪流、连廊和院落场景基线。
4. Phase5持久化登录、world快照和刷新恢复。
5. admin/editor/viewer角色权限与地块隔离。
6. 拖拽式家园装扮编辑器。
7. 多人在线Avatar互见与位置同步。
8. Avatar idle/walk程序化动画及状态同步。
9. 在线用户列表。
10. 全局世界文字聊天与历史消息持久化。

### 12.7 待办任务列表

1. 扩充家具、绿植和装饰素材库。
2. 增加Avatar更多动作、表情和外观选择。
3. 增加私聊、附近频道或频道切换。
4. 项目整体打包、全套验收文档和部署上线准备。
5. 根据部署环境补充正式身份密钥、服务令牌和CORS域名配置。

## 13. 家园装饰素材库扩充

### 13.1 阶段信息

阶段名称：家园装饰素材库扩充

状态：开发完成，自测通过。

### 13.2 变更内容

- 新增`户外绿植`分类：竹林组景、蕨类灌木、藤蔓屏风、橄榄树。
- 新增`盆栽`分类：陶盆绿植、松柏盆景、陶盆花束、悬挂花篮。
- 新增`景观石`分类：立景石、叠石组、卵石小景、石灯笼。
- 新增`灯笼`分类：纸灯笼、木框灯笼、节庆灯笼、落地灯笼。
- 新增`装饰摆件`分类：木雕摆件、陶罐摆件、风铃挂饰、庭院木牌。
- 新增`室内软装`分类：草编地毯、布艺坐垫、亚麻矮榻、木格屏风、针织毛毯。
- 所有新增素材复用现有拖拽、移动、旋转、删除和保存逻辑。
- 新增素材通过`materialId`写入world快照，不需要修改Phase5表结构。
- 新增零成本素材会自动加入默认解锁列表。
- 编辑器分类白名单已扩展，新分类可直接显示。

### 13.3 持久化验证

- 新增`pot-ceramic`素材已在真实Phase5临时数据库中完成写入。
- 新建前端Store后成功读取并恢复室内盆栽配置。
- 编辑器E2E验证院落与室内新增素材的放置、移动、旋转、删除和刷新恢复。

### 13.4 当前完整能力清单

1. Three.js 3D山谷世界漫游。
2. 昼夜切换、雾气、风动和样板室内模式。
3. 50户木屋、生活广场、溪流、连廊和院落场景基线。
4. Phase5持久化登录、world快照和刷新恢复。
5. admin/editor/viewer角色权限与地块隔离。
6. 拖拽式家园装扮编辑器。
7. 院落与室内双模式家具摆放。
8. 家具、绿植、盆栽、景观石、灯笼、摆件和室内软装素材库。
9. 多人在线Avatar互见与位置同步。
10. Avatar idle/walk程序化动画及状态同步。
11. 在线用户列表。
12. 全局世界文字聊天与历史消息持久化。

### 13.5 待办任务列表

1. 增加素材分类搜索、收藏和最近使用。
2. 增加更多家具变体、季节限定素材和主题套装。
3. 增加Avatar更多动作、表情和外观选择。
4. 增加私聊、附近频道或频道切换。
5. 项目整体打包、全套验收文档和部署上线准备。
6. 根据部署环境补充正式身份密钥、服务令牌和CORS域名配置。

## 14. 项目打包验收与部署文档

### 14.1 阶段信息

阶段名称：虚拟乌托邦项目打包验收与部署文档全套生成

状态：开发完成，自测通过。

### 14.2 变更内容

- 新增完整项目验收报告`docs/ACCEPTANCE_REPORT_V2.md`。
- 新增本地部署指南`docs/LOCAL_DEPLOYMENT_GUIDE.md`。
- 新增环境依赖清单`docs/ENVIRONMENT_DEPENDENCIES.md`。
- 新增启动、停止、备份和排障手册`docs/OPERATIONS_MANUAL.md`。
- 新增Phase2、Phase5、Phase6和RAG完整API接口文档`docs/API_REFERENCE.md`。
- 新增交付包内容清单`docs/DELIVERY_MANIFEST.md`。
- 生成结构化完整交付ZIP包。
- 交付包排除`node_modules`、真实`.env`、运行时SQLite和临时产物。
- 交付包保留后端、前端、测试、脚本、数据库结构、全部Markdown文档和memory知识库。

### 14.3 交付包

文件：

```text
H:\BP2\deliverables\virtual-utopia-bp2-delivery-20260917-v1.1-structured.zip
```

SHA256：

```text
2A61A005DC3E2050C29D322107B7B634454EFC3353363D4B7FE0F3A176D77DFD
```

校验文件：

```text
H:\BP2\deliverables\virtual-utopia-bp2-delivery-20260917-v1.1-structured.zip.sha256
```

### 14.4 回归验证

- `npm run check`通过。
- 前端基础测试9/9通过。
- 后端基础测试33/33通过。
- WebGL世界E2E通过。
- 家园编辑器E2E通过。
- Avatar在线与动画E2E通过。
- 世界聊天E2E通过。
- Phase6网关E2E通过。
- 真实Phase5持久化E2E通过。

### 14.5 当前完整能力清单

1. Three.js 3D山谷世界漫游。
2. 昼夜切换、雾气、风动和样板室内模式。
3. 50户木屋、生活广场、溪流、连廊和院落场景基线。
4. Phase5持久化登录、world快照和刷新恢复。
5. admin/editor/viewer角色权限与地块隔离。
6. 拖拽式家园装扮编辑器。
7. 院落与室内双模式家具摆放。
8. 家具、绿植、盆栽、景观石、灯笼、摆件和室内软装素材库。
9. 多人在线Avatar互见与位置同步。
10. Avatar idle/walk程序化动画及状态同步。
11. 在线用户列表。
12. 全局世界文字聊天与历史消息持久化。
13. 完整验收、部署、环境、运维和API文档。
14. 结构化源码与文档交付包。

### 14.6 待办任务列表

1. 增加素材分类搜索、收藏和最近使用。
2. 增加更多家具变体、季节限定素材和主题套装。
3. 增加Avatar更多动作、表情和外观选择。
4. 增加私聊、附近频道或频道切换。
5. 补充正式域名、HTTPS、反向代理和生产密钥管理。
6. 根据部署规模评估WebSocket替代短轮询和集中式数据库迁移。
