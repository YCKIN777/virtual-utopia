# 虚拟乌托邦 BP2 项目检验验收报告

## 1. 项目基本信息

| 项目 | 内容 |
| --- | --- |
| 项目名称 | virtual-utopia BP2 |
| 交付版本 | `0.1.0` |
| 开发与自测记录日期 | `2026-09-16` |
| 验收环境 | Windows x64、Node.js `v24.18.0`、npm `11.16.0` |
| 验收方式 | 项目整体自测验收 |
| 验收目的 | 验证Phase1至Phase5交付成果完整、冻结版本可运行、全量回归通过、阶段边界清晰 |

本次验收覆盖阶段一至阶段五全部已完成功能，不包含尚未开发的新业务。

## 2. 项目总体概述

### 2.1 Phase1：工程、UI与场景外壳

阶段目标：

- 建立前端、后端和本地工程基础。
- 完成全局HIG组件、等轴测矢量地图和六场景容器。
- 支持桌面端和移动端响应式展示。

交付成果：

- Vue 3、Vite、Vue Router、TailwindCSS前端。
- Express后端和基础健康接口。
- 按钮、卡片、弹窗、输入框、滚动容器和Toast等HIG组件。
- Canvas等轴测网格和SVG六点位建筑地图。
- 大院、议事亭、资源墙、书屋、小屋、远林六场景路由。
- PostgreSQL空表Schema占位，但不作为当前运行数据库。

### 2.2 Phase2：Agent与会话

阶段目标：

- 建立五个分支Agent和场景映射。
- 实现前端场景切换、消息收发和会话隔离。
- 保持公共会话与私聊会话边界。

交付成果：

- 阿禾-大院、知予-资源墙、叙白-议事亭、岁安-书屋、风禾-小屋。
- 远林不绑定Agent，前端禁止提交。
- 公共会话按场景隔离。
- 小屋私聊使用`prv_`会话，仅风禾可访问。
- 内存会话TTL、容量清理、越权和非法会话错误处理。
- 真实DeepSeek场景E2E，五个可用场景验证通过。

### 2.3 Phase3：RAG知识库

阶段目标：

- 新增独立RAG服务。
- 实现文档加载、分块、向量入库和相似度召回。

交付成果：

- `backend/src/rag/`独立RAG服务，监听`3100`。
- ChromaDB Node SDK和默认集合`virtual_utopia_rag`。
- `.md`、`.txt`文档加载和UTF-8读取。
- 默认800字符分块、120字符重叠和确定性chunkID。
- ChromaDB向量入库与余弦距离召回。
- 返回`chunk`、`source`、`chunkIndex`、`distance`、`similarity`。

### 2.4 Phase4：RAG与主Agent集成

阶段目标：

- 通过开关控制RAG检索增强。
- 将有效召回片段注入DeepSeek System Prompt。

交付成果：

- `backend/src/phase4/`独立集成模块。
- `ENABLE_RAG_ENHANCE`总开关，默认关闭。
- 相似度阈值和TopK配置。
- 开启时调用RAG并注入参考资料。
- 关闭时保持原Agent模型调用路径。
- 不修改原场景映射、会话隔离和Agent人设。

### 2.5 Phase5：SQLite持久化服务

阶段目标：

- 新增独立SQLite持久化元数据服务。
- 提供用户、会话、文档元数据和RAG日志持久化。
- 支持内存与SQLite双存储模式。

交付成果：

- `backend/src/phase5/`独立HTTP服务，默认监听`3300`。
- Node.js内置`node:sqlite`，启用WAL、外键和超时配置。
- `users`、`chat_sessions`、`knowledge_documents`、`rag_logs`四张表。
- 用户登录、角色鉴权和用户管理。
- 会话CRUD和服务重启恢复。
- 文档元数据CRUD。
- RAG日志写入和查询。
- `SESSION_STORAGE_MODE=memory|sqlite`模式切换。
- 不修改Phase1至Phase4源码。

## 3. 系统架构说明

```text
浏览器 5173
    │
    ▼
Vue 3 / Vite 前端
    │
    │ POST /api/scene/route
    ▼
Phase4主服务 3200
    │
    ├─ SESSION_STORAGE_MODE=memory
    │    └─ 原内存会话
    │
    ├─ SESSION_STORAGE_MODE=sqlite
    │    └─ HTTP → Phase5持久服务 3300 → SQLite元数据
    │
    ├─ ENABLE_RAG_ENHANCE=false
    │    └─ 直接调用DeepSeek
    │
    └─ ENABLE_RAG_ENHANCE=true
         │
         │ POST /api/rag/query
         ▼
       RAG服务 3100
         │
         ▼
       ChromaDB 8000
         │
         └─ 返回文档片段和相似度
              │
              ▼
         阈值过滤后注入DeepSeek System Prompt
              │
              ▼
          DeepSeek接口
```

关键边界：

- ChromaDB保存向量和文档chunk。
- Phase5 SQLite只保存元数据、会话、用户和日志。
- Phase5不接管向量存储。
- `memory`模式完全不调用Phase5。
- `sqlite`模式通过HTTP使用Phase5持久化适配器。

## 4. 功能验收清单

### 4.1 Phase1功能验收

| 验收项 | 预期结果 | 实测结果 | 验收结论 |
| --- | --- | --- | --- |
| 前端生产构建 | Vite构建成功 | 构建成功，52个模块完成转换 | 通过 |
| HIG组件 | 基础组件可复用且样式统一 | 按钮、卡片、弹窗、输入框、滚动容器、Toast可用 | 通过 |
| 等轴测地图 | Canvas和SVG正常渲染 | 六点位地图正常渲染 | 通过 |
| 地图交互 | hover、点击、展开/收起正常 | 实测通过 | 通过 |
| 六场景路由 | 六个点位可独立访问 | 六条路由均通过 | 通过 |
| 响应式布局 | 桌面和移动端无横向溢出 | 实测通过 | 通过 |

### 4.2 Phase2功能验收

| 验收项 | 预期结果 | 实测结果 | 验收结论 |
| --- | --- | --- | --- |
| Agent场景映射 | 五场景绑定正确Agent | 五个Agent映射正确 | 通过 |
| 远林限制 | 不允许提交消息 | 不产生后端请求 | 通过 |
| 公共场景隔离 | 不同场景上下文独立 | 场景切换后历史不串话 | 通过 |
| 私聊隔离 | 小屋会话使用`prv_`且仅风禾可读 | 越权返回`403 SESSION_SCOPE_VIOLATION` | 通过 |
| 非法会话 | 返回明确错误 | 返回`400 INVALID_SESSION_ID` | 通过 |
| 真实模型E2E | 五个可用场景完整通过 | 使用真实DeepSeek接口完成验证 | 通过 |

### 4.3 Phase3功能验收

| 验收项 | 预期结果 | 实测结果 | 验收结论 |
| --- | --- | --- | --- |
| 文档加载 | 支持`.md`和`.txt` | 加载和UTF-8读取通过 | 通过 |
| 文本分块 | 默认800字符、重叠120字符 | 分块及稳定chunkID通过 | 通过 |
| 向量入库 | 写入ChromaDB | 入库成功 | 通过 |
| 相似度召回 | 返回最相关chunk和距离 | 召回成功 | 通过 |
| 返回字段 | 包含chunk、source、chunkIndex、distance、similarity | 字段完整 | 通过 |

### 4.4 Phase4功能验收

| 验收项 | 预期结果 | 实测结果 | 验收结论 |
| --- | --- | --- | --- |
| RAG开关开启 | 调用RAG并注入参考资料 | RAG请求1次，参考片段注入成功 | 通过 |
| RAG开关关闭 | 不调用RAG，保持原Agent逻辑 | RAG请求0次，回答保持基础链路 | 通过 |
| 相似度阈值 | 低于阈值结果被丢弃 | 集成模块执行阈值过滤 | 通过 |
| 提示词注入 | 参考资料追加到System Prompt | 注入位置和内容验证通过 | 通过 |
| 原Agent逻辑 | 场景、会话和路由逻辑不变 | 回归测试通过 | 通过 |

### 4.5 Phase5功能验收

| 验收项 | 预期结果 | 实测结果 | 验收结论 |
| --- | --- | --- | --- |
| SQLite初始化 | 自动创建四张表 | 建表、索引和外键初始化通过 | 通过 |
| 用户登录 | 正确账号登录成功 | 管理员和editor登录通过 | 通过 |
| 角色鉴权 | admin/editor/viewer权限区分 | 鉴权逻辑和接口保护通过 | 通过 |
| 会话持久化 | 服务重启后消息不丢失 | 重启后2条消息仍可读取 | 通过 |
| 文档元数据 | 新增、更新、列表、删除持久化 | 重启后chunkCount和状态保持 | 通过 |
| RAG日志 | 写入和查询正常 | 重启后日志记录仍可查询 | 通过 |
| memory模式 | 完全不调用Phase5 | Phase5调用次数为0 | 通过 |
| sqlite模式 | 使用持久化存储 | 重启后会话恢复成功 | 通过 |

说明：当前实际角色为`admin`、`editor`、`viewer`，不存在`guest`角色。

## 5. 非功能验收项

### 5.1 代码规范

- 新增JavaScript文件均通过`node --check`。
- 保留阶段一至阶段四原有测试和接口。
- Phase5代码独立放在`backend/src/phase5`。
- 未修改已冻结源码和记忆文档。

### 5.2 文件编码

- 新增源码和文档使用UTF-8。
- 未写入UTF-8 BOM。
- 换行格式为LF。

### 5.3 可部署性

- 前端可通过Vite构建。
- 后端以Node.js源码运行。
- RAG、Phase5和Phase4服务均支持本地独立启动。
- Chroma、SQLite数据目录均在项目外或独立目录维护。

### 5.4 容错能力

- Phase2网络异常、加载态和错误Toast已覆盖。
- Phase5 SQLite模式遇到服务不可用时返回明确错误。
- Phase5 memory模式不依赖Phase5服务。
- RAG增强关闭时不会访问RAG服务。
- 错误响应使用结构化JSON。

### 5.5 安全基础

- Phase5用户密码使用`scrypt`哈希保存。
- 登录使用HMAC签名Bearer Token。
- 服务间调用使用`X-Phase5-Service-Token`。
- 角色权限限制会话、文档和日志访问。

## 6. 环境与部署验收

### 6.1 运行环境

- Windows x64。
- Node.js `v24.18.0`。
- npm `11.16.0`。
- ChromaDB独立服务。
- DeepSeek API配置。
- 项目原有`.env`未修改。

### 6.2 完整启动顺序

`Chroma 8000 → Phase3 RAG服务 3100 → Phase5持久服务 3300 → Phase4主服务 3200 → 前端 5173`

### 6.3 服务端口

| 服务 | 端口 | 状态 |
| --- | --- | --- |
| ChromaDB | `8000` | 可启动 |
| RAG服务 | `3100` | 健康检查通过 |
| Phase5持久服务 | `3300` | 健康检查和登录验证通过 |
| Phase4主服务 | 推荐`3200`，代码默认`3000` | 健康检查通过 |
| 前端 | `5173` | Vite开发服务可启动 |

### 6.4 数据存储边界

- ChromaDB：保存RAG向量和文档chunk。
- SQLite：只保存用户、会话、文档元数据和RAG日志。
- SQLite不保存向量。
- Phase5不直接改写RAG或DeepSeek业务逻辑。

### 6.5 部署文档

`docs/deployment.md`提供阶段一至阶段四的打包和本地部署说明。Phase5启动和双存储模式说明已归档在`stage5_memory.md`。后续如发布统一部署包，应将Phase5服务和3300端口合并进同一部署文档版本。

## 7. 回归测试结论

| 测试 | 结果 |
| --- | --- |
| 前端生产构建 | 通过 |
| 前端测试 | 9/9通过 |
| 后端原有语法检查 | 通过 |
| 阶段二后端测试 | 33/33通过 |
| 阶段二真实DeepSeek E2E | 5个可用场景通过 |
| 阶段三向量E2E | 入库和召回通过 |
| 阶段四RAG-Agent集成E2E | 开启/关闭双链路通过 |
| 阶段五SQLite持久化E2E | 重启持久化、双模式通过 |
| `npm run check` | 通过 |
| 原有阶段测试 | 全部保留，无失败 |

## 8. 缺陷说明

当前版本未发现已知重大缺陷。

已知非阻断限制：

- Windows x64下`chromadb@3.5.0`自带CLI存在架构限制，需使用Windows绑定启动方式。
- Phase5依赖Node.js内置`node:sqlite`，建议Node.js`>=22.5`。
- Linux和macOS尚未执行完整项目验收。
- PostgreSQL Schema仍为阶段一空表占位，不属于Phase5当前运行数据库。
- Phase5前端登录、文档列表和对话历史界面尚未纳入本轮交付。

以上限制不影响阶段一至阶段五已完成能力的自测验收结论。

## 9. 验收结论

Phase1至Phase5已完成阶段性开发、自测和冻结准备：

- Phase1工程、UI和地图场景外壳通过验收。
- Phase2 Agent、场景绑定、会话隔离和真实模型E2E通过。
- Phase3 RAG文档入库、向量存储和召回通过。
- Phase4 RAG开关、阈值过滤和System Prompt注入通过。
- Phase5 SQLite元数据持久化、双存储模式和重启恢复通过。
- 全量基础回归测试通过。

本次验收结论：通过整体自测验收，当前交付版本可作为冻结版本进入整体项目验收流程。

## 10. 验收签字栏

| 角色 | 姓名/部门 | 签字 | 日期 |
| --- | --- | --- | --- |
| 开发方 |  |  |  |
| 验收方 |  |  |  |
| 项目负责人 |  |  |  |
| 归档人 |  |  |  |

---

本项目阶段1~5全部冻结，本次验收为整体自测验收。
