import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createAuditStore } from './auditStore.js';
import { createPhase6App } from './app.js';
import {
  readPhase6Config,
  validatePhase6Config,
} from './config.js';

export const startPhase6Server = async ({
  config = readPhase6Config(),
} = {}) => {
  validatePhase6Config(config);
  const auditStore = createAuditStore(config.auditDatabasePath);
  const app = createPhase6App({
    config,
    auditStore,
  });
  const server = await new Promise((resolve, reject) => {
    const listeningServer = app.listen(
      config.port,
      config.host,
    );

    listeningServer.once('listening', () =>
      resolve(listeningServer),
    );
    listeningServer.once('error', reject);
  });

  const close = async () =>
    new Promise((resolve, reject) => {
      server.close((error) => {
        auditStore.close();

        if (error) {
          reject(error);
          return;
        }

        resolve();
      });
    });

  return {
    app,
    server,
    auditStore,
    close,
  };
};

const isDirectExecution =
  process.argv[1] &&
  path.resolve(process.argv[1]) === fileURLToPath(import.meta.url);

if (isDirectExecution) {
  const config = readPhase6Config();

  startPhase6Server({ config })
    .then(({ server }) => {
      console.log(
        JSON.stringify({
          service: 'virtual-utopia-phase6',
          host: config.host,
          port: server.address().port,
          auditDatabasePath: config.auditDatabasePath,
        }),
      );
    })
    .catch((error) => {
      console.error(error.stack || error);
      process.exitCode = 1;
    });
}
