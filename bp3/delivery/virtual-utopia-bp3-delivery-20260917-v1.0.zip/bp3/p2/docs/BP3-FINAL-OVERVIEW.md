# 虚拟乌托邦 BP3 最终总览

## 版本

```text
BP3 M1 + M2 + M3
```

状态：开发完成，全链路验收通过。

## 模块

| 模块 | 范围 | 目录 |
| --- | --- | --- |
| M1 P0 | 语音、家园权限、门锁、访客 | `bp3/` |
| M2 P1 | 事件、任务、资源、背包 | `bp3/p1/` |
| M3 P2 | Avatar动作表情、家园留言板 | `bp3/p2/` |

三个模块共享BP3独立数据库，但使用独立服务入口和独立数据表前缀：

```text
bp3_       M1
bp3_p1_    M2
bp3_p2_    M3
```

## 数据文件

```text
H:\BP2\bp3\data\virtual_utopia_bp3.sqlite
```

## 冻结边界

- BP2源码、3D场景美术、冻结交付包和Obsidian归档保持不变。
- M1、M2原有代码保持不变。
- M3仅新增`bp3/p2`目录。
- 不修改Phase5的`users`、`chat_sessions`、`knowledge_documents`和`rag_logs`表结构。

## 全链路

```text
Phase5身份
  -> M1语音与权限
  -> M2事件、任务、资源、背包
  -> M3 Avatar状态与家园留言
```

全链路E2E会同时启动M1、M2、M3服务和临时数据库，
验证跨模块数据表兼容、语音频道加入、事件任务背包闭环、
Avatar状态同步和留言权限。
